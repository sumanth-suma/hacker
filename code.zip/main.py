"""Deterministic, evidence-grounded deletion audit agent.

Uses only the participant-facing dataset.  The parser deliberately treats
workflow activity as a lead, while evidence snapshots/readbacks establish
resource state at the requested audit cut-off.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
DIRECT_FIELDS = {"email", "phone", "email_hash", "full_name", "name", "display_name",
                 "requester_email", "requester_phone", "owner_email", "owner_phone", "customer_email"}
SYSTEM_CATEGORY = {
    "account_service": "USER_PROFILE", "profile_service": "USER_PROFILE",
    "search_service": "SEARCH_INDEX_ENTRY", "cache_service": "CACHE_ENTRY",
    "support_platform": "SUPPORT_MESSAGE", "analytics_platform": "ANALYTICS_PROFILE",
    "telemetry_service": "PRODUCT_TELEMETRY", "export_service": "USER_EXPORT",
    "marketing_platform": "MARKETING_PROFILE", "delivery_service": "EMAIL_DELIVERY_LOG",
    "security_service": "SECURITY_AUDIT_LOG", "legal_service": "LEGAL_HOLD_RECORD",
    "backup_service": "BACKUP_ARCHIVE", "integration_service": "DATA_FLOW",
    "identity_service": "ACCOUNT_TOMBSTONE",
}
LEGACY_TABLE_SYSTEMS = {
    "customer_profiles": "account_service", "customer_profiles_primary": "account_service",
    "customer_profiles_failover_replica": "account_service", "customer_search_documents": "search_service",
    "customer_analytics_profiles": "analytics_platform", "support_records": "support_platform",
    "customer_exports": "export_service", "connector_subscriptions": "integration_service",
    "backup_restore_entries": "backup_service", "security_audit_records": "security_service",
}
FIND_ORDER = {"REPORT_REMAINING_RECORD": 0, "REPORT_EXPOSED_PII": 1,
              "REPORT_ACTIVE_DATA_FLOW": 2, "REPORT_RESTORE_RISK": 3}
FIX_ORDER = {"DISABLE_DATA_FLOW": 0, "BLOCK_RESTORE": 1, "DELETE_RECORD": 2,
             "REDACT_RECORD": 3, "ANONYMIZE_RECORD": 4}
VERIFY_ORDER = {"VERIFY_RECORD_ABSENT": 0, "VERIFY_RECORD_PRESENT": 1,
                "VERIFY_RECORD_REDACTED": 2, "VERIFY_RECORD_ANONYMIZED": 3,
                "VERIFY_DATA_FLOW_DISABLED": 4, "VERIFY_RESTORE_BLOCKED": 5}


def ts(value: str | None) -> datetime:
    if not value:
        return datetime.min.replace(tzinfo=timezone.utc)
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def norm(value: Any) -> str:
    return str(value or "").strip().casefold()


def iter_dicts(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from iter_dicts(child)
    elif isinstance(value, list):
        for child in value:
            yield from iter_dicts(child)


@dataclass(frozen=True)
class Identity:
    user_id: str
    identifiers: frozenset[str]


@dataclass
class Observation:
    evidence_id: str
    observed_at: datetime
    system_id: str
    resource_id: str
    present: bool
    pii: bool
    active: bool | None = None
    restore_allowed: bool | None = None
    category: str | None = None


class IdentityResolver:
    def __init__(self, dataset: Path):
        self.by_identifier: dict[str, set[str]] = defaultdict(set)
        self.identifiers: dict[str, set[str]] = defaultdict(set)
        for filename in ("user_identities.csv", "user_audit_log.csv"):
            with (dataset / filename).open(encoding="utf-8", newline="") as handle:
                for row in csv.DictReader(handle):
                    user_id = row["user_id"]
                    values = ([row.get(k, "") for k in ("name", "email", "phone", "email_hash")]
                              if filename == "user_identities.csv" else [row.get("old_value", ""), row.get("new_value", "")])
                    for value in values:
                        value = norm(value)
                        if value:
                            self.by_identifier[value].add(user_id)
                            self.identifiers[user_id].add(value)

    def resolve(self, email: str) -> Identity | None:
        ids = self.by_identifier.get(norm(email), set())
        if len(ids) != 1:
            return None
        user_id = next(iter(ids))
        return Identity(user_id, frozenset(self.identifiers[user_id] | {norm(user_id)}))


class EvidenceParser:
    def __init__(self, dataset: Path):
        self.dataset = dataset
        self.manifest = list(csv.DictReader((dataset / "evidence_files.csv").open(encoding="utf-8", newline="")))
        self.text_cache: dict[str, str] = {}
        self.sql_cache: dict[str, list[tuple[str, dict[str, Any]]]] = {}
        for entry in self.manifest:
            path = self.dataset / entry["file_path"]
            if not path.exists() or path.suffix.lower() == ".png":
                continue
            text = self._pdf_text(path) if path.suffix.lower() == ".pdf" else path.read_text(encoding="utf-8", errors="replace")
            self.text_cache[entry["file_id"]] = text
            if path.suffix.lower() == ".sql":
                self.sql_cache[entry["file_id"]] = self._load_sql_rows(text)

    @staticmethod
    def _system_from_collection(value: str) -> str:
        value = value.lower()
        if value in LEGACY_TABLE_SYSTEMS:
            return LEGACY_TABLE_SYSTEMS[value]
        for system, category in SYSTEM_CATEGORY.items():
            if system.split("_")[0] in value or category.lower().split("_")[0] in value:
                return system
        return "unknown_service"

    @staticmethod
    def _pdf_text(path: Path) -> str:
        try:
            from pypdf import PdfReader
            return "\n".join(page.extract_text() or "" for page in PdfReader(path).pages)
        except Exception:
            return ""

    def _pdf_observations(self, text: str, evidence_id: str, captured: datetime, identity: Identity) -> list[Observation]:
        if not any(token in norm(text) for token in identity.identifiers):
            return []
        resources = re.findall(r"\b(support_\d+)\b", text, flags=re.IGNORECASE)
        return [Observation(evidence_id, captured, "support_platform", resource, True, True,
                            category="SUPPORT_ATTACHMENT") for resource in sorted(set(resources))]

    @staticmethod
    def _fields_have_pii(record: dict[str, Any]) -> bool:
        for item in iter_dicts(record):
            if any(item.get(key) not in (None, "", "null") for key in DIRECT_FIELDS):
                return True
        return False

    @staticmethod
    def _matches(record: dict[str, Any], identity: Identity) -> bool:
        values = set()
        for item in iter_dicts(record):
            values.update(norm(v) for v in item.values() if not isinstance(v, (dict, list)))
        return bool(values & identity.identifiers)

    def _load_sql_rows(self, text: str) -> list[tuple[str, dict[str, Any]]]:
        parsed: list[tuple[str, dict[str, Any]]] = []
        db = sqlite3.connect(":memory:")
        try:
            db.executescript(text)
            for (table,) in db.execute("select name from sqlite_master where type='table'"):
                if table == "snapshot_scope":
                    continue
                columns = [x[1] for x in db.execute(f'pragma table_info("{table}")')]
                for values in db.execute(f'select * from "{table}"'):
                    row = dict(zip(columns, values))
                    if isinstance(row.get("record_json"), str):
                        try:
                            structured = json.loads(row["record_json"])
                        except json.JSONDecodeError:
                            structured = {}
                        if isinstance(structured, dict):
                            row.update(structured)
                    parsed.append((row.get("origin_system") or self._system_from_collection(table), row))
        except sqlite3.Error:
            pass
        finally:
            db.close()
        return parsed

    def _json_observations(self, data: Any, evidence_id: str, captured: datetime, identity: Identity) -> list[Observation]:
        result: list[Observation] = []
        # Records assurance bundles carry explicit per-snapshot timestamps and systems.
        for item in iter_dicts(data):
            records = item.get("records")
            if not isinstance(records, list):
                continue
            system = item.get("data_store") or self._system_from_collection(item.get("collection", ""))
            observed = ts(item.get("captured_at")) if item.get("captured_at") else captured
            for record in records:
                flat = dict(record)
                if isinstance(flat.get("document"), dict):
                    flat.update(flat["document"])
                if not self._matches(flat, identity):
                    continue
                result.append(Observation(evidence_id, observed, system, str(flat.get("resource_id", "")), True,
                                          self._fields_have_pii(flat), category=SYSTEM_CATEGORY.get(system)))
        # Resource exports have records nested under arbitrary service names.
        exports = data.get("service_exports", {}) if isinstance(data, dict) else {}
        for system, groups in exports.items():
            for group in groups.values() if isinstance(groups, dict) else []:
                for record in group if isinstance(group, list) else []:
                    if not isinstance(record, dict) or not self._matches(record, identity):
                        continue
                    present = record.get("status_code") != 404 and record.get("profile") is not None
                    active = record.get("enabled") if "enabled" in record else None
                    restore = record.get("restore_allowed") if "restore_allowed" in record else None
                    result.append(Observation(evidence_id, ts(record.get("observed_at")) if record.get("observed_at") else captured,
                                              system, str(record.get("resource_id", "")), present,
                                              self._fields_have_pii(record.get("profile") or record), active, restore,
                                              SYSTEM_CATEGORY.get(system)))
        return result

    def _sql_observations(self, text: str, evidence_id: str, captured: datetime, identity: Identity) -> list[Observation]:
        result: list[Observation] = []
        for system, row in self.sql_cache.get(evidence_id, []):
            if not self._matches(row, identity):
                continue
            result.append(Observation(evidence_id, captured, system, str(row.get("resource_id", "")), True,
                                      self._fields_have_pii(row), row.get("enabled") == 1 if "enabled" in row else None,
                                      row.get("restore_allowed") == 1 if "restore_allowed" in row else None,
                                      SYSTEM_CATEGORY.get(system)))
        return result

    def _log_observations(self, text: str, evidence_id: str, captured: datetime, identity: Identity) -> list[Observation]:
        result: list[Observation] = []
        related_traces = set()
        for line in text.splitlines():
            if any(token in norm(line) for token in identity.identifiers):
                match = re.search(r"trace_id=([\w-]+)", line)
                if match:
                    related_traces.add(match.group(1))
        for line in text.splitlines():
            system_m = re.search(r"(?:service|system)=([\w-]+)", line)
            resource_m = re.search(r"resource_id=([\w-]+)", line)
            if not (system_m and resource_m):
                continue
            system, resource = system_m.group(1), resource_m.group(1)
            trace_m = re.search(r"trace_id=([\w-]+)", line)
            linked = trace_m and trace_m.group(1) in related_traces
            if not any(token in norm(line) for token in identity.identifiers) and not linked:
                continue
            low = line.casefold()
            event_m = re.search(r"event=([\w-]+)", line)
            event = event_m.group(1) if event_m else ""
            if linked and not (event.endswith("_completed") or event in {"connector_heartbeat", "restore_candidate_evaluated"}):
                continue
            system = {"support_replica": "support_platform"}.get(system, system)
            present = not ("rows=0" in low or "404" in low or "result=miss" in low)
            active = True if "enabled=true" in low else False if "enabled=false" in low else None
            restore = True if "restore_allowed=true" in low else False if "restore_allowed=false" in low else None
            result.append(Observation(evidence_id, ts(line[:20]) if re.match(r"\d{4}-", line) else captured,
                                      system, resource, present,
                                      any(k + "=" in low for k in ("email", "phone", "matched_value")), active, restore,
                                      SYSTEM_CATEGORY.get(system)))
        for line in text.splitlines():
            parts = [part.strip() for part in line.split("|")]
            if len(parts) < 6 or not any(token in norm(line) for token in identity.identifiers):
                continue
            when, system, resource, _category, state = parts[:5]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", when):
                continue
            if system not in SYSTEM_CATEGORY:
                continue
            state = state.casefold()
            result.append(Observation(evidence_id, ts(when), system, resource, state not in {"absent", "not_found"},
                                      state in {"present", "found", "active", "identifiable"},
                                      True if system == "integration_service" and state == "active" else False if system == "integration_service" and state == "disabled" else None,
                                      True if system == "backup_service" and state == "active" else False if system == "backup_service" and state == "blocked" else None,
                                      SYSTEM_CATEGORY.get(system)))
        return result

    def observations(self, identity: Identity, audit_at: datetime) -> list[Observation]:
        result: list[Observation] = []
        for entry in self.manifest:
            captured = ts(entry["captured_at"])
            if captured > audit_at:
                continue
            path = self.dataset / entry["file_path"]
            if not path.exists() or path.suffix.lower() == ".png":
                continue  # Binary OCR/PDF extraction is intentionally optional, never fabricated.
            text = self.text_cache.get(entry["file_id"], "")
            # Avoid executing every SQL snapshot for every case.  The evidence
            # contract requires an identifier-grounded link, so no absent token
            # means the artifact cannot establish a fact about this subject.
            lower_text = text.casefold()
            if not any(identifier in lower_text for identifier in identity.identifiers):
                continue
            if path.suffix.lower() == ".json":
                try:
                    result.extend(self._json_observations(json.loads(text), entry["file_id"], captured, identity))
                except json.JSONDecodeError:
                    pass
            elif path.suffix.lower() == ".sql":
                result.extend(self._sql_observations(text, entry["file_id"], captured, identity))
            elif path.suffix.lower() == ".pdf":
                result.extend(self._pdf_observations(text, entry["file_id"], captured, identity))
            else:
                result.extend(self._log_observations(text, entry["file_id"], captured, identity))
        return result


class AuditEngine:
    def __init__(self, dataset: Path):
        self.dataset, self.resolver, self.evidence = dataset, IdentityResolver(dataset), EvidenceParser(dataset)
        self.rules = {row["data_category"]: row["required_action"]
                      for row in csv.DictReader((dataset / "deletion_rules.csv").open(encoding="utf-8", newline=""))}

    @staticmethod
    def deletion_authorized(text: str) -> bool:
        text = norm(text)
        delete_words = ("delete", "delet", "remove", "erasure", "suppression", "supprimer", "eliminar", "elimin", "borrar", "erase", "closed", "close my", "close this", "permanent", "disconnect", "削除")
        # A verification request can still authorize deletion when it explicitly asks
        # whether a previously submitted deletion has actually completed.
        verification_of_deletion = "account" in text and any(
            phrase in text for phrase in ("removed", "deleted", "profile is gone", "profile gone")
        )
        return any(word in text for word in delete_words) or verification_of_deletion

    def _action(self, obs: Observation) -> str:
        if obs.system_id == "integration_service":
            return "DISABLE_DATA_FLOW"
        if obs.system_id == "backup_service":
            return "BLOCK_RESTORE"
        return {"DELETE": "DELETE_RECORD", "REDACT": "REDACT_RECORD", "ANONYMIZE": "ANONYMIZE_RECORD"}.get(
            self.rules.get(obs.category or "", "DELETE"), "DELETE_RECORD")

    @staticmethod
    def _verify(action: str) -> tuple[str, str]:
        return {"DELETE_RECORD": ("VERIFY_RECORD_ABSENT", "ABSENT"), "REDACT_RECORD": ("VERIFY_RECORD_REDACTED", "REDACTED"),
                "ANONYMIZE_RECORD": ("VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"), "DISABLE_DATA_FLOW": ("VERIFY_DATA_FLOW_DISABLED", "DISABLED"),
                "BLOCK_RESTORE": ("VERIFY_RESTORE_BLOCKED", "BLOCKED")}[action]

    @staticmethod
    def _step(phase: str, system: str, resource: str, operation: str, state: str, evidence: str) -> dict[str, Any]:
        return {"step_no": 0, "phase": phase, "system_id": system, "resource_id": resource,
                "operation": operation, "state": state, "evidence_id": evidence}

    def audit(self, request: dict[str, str]) -> tuple[str, list[dict[str, Any]]]:
        if not self.deletion_authorized(request["request_text"]):
            return "NOT_APPLICABLE", []
        identity = self.resolver.resolve(request["email"])
        if not identity:
            return "INCOMPLETE", []
        observations = self.evidence.observations(identity, ts(request["audit_at"]))
        latest: dict[tuple[str, str], Observation] = {}
        for obs in observations:
            key = (obs.system_id, obs.resource_id)
            if key not in latest or latest[key].observed_at <= obs.observed_at:
                latest[key] = obs
        findings: list[dict[str, Any]] = []
        compliant: list[dict[str, Any]] = []
        remedies: list[dict[str, Any]] = []
        verification: list[dict[str, Any]] = []
        for obs in latest.values():
            action = self._action(obs)
            violation = ((obs.system_id == "integration_service" and obs.active is True) or
                         (obs.system_id == "backup_service" and obs.restore_allowed is True) or
                         (obs.present and action == "DELETE_RECORD") or
                         (obs.present and action in {"REDACT_RECORD", "ANONYMIZE_RECORD"} and obs.pii))
            if violation:
                finding = ("REPORT_ACTIVE_DATA_FLOW" if action == "DISABLE_DATA_FLOW" else
                           "REPORT_RESTORE_RISK" if action == "BLOCK_RESTORE" else
                           "REPORT_EXPOSED_PII" if action in {"REDACT_RECORD", "ANONYMIZE_RECORD"} else "REPORT_REMAINING_RECORD")
                findings.append(self._step("FINDING", obs.system_id, obs.resource_id, finding,
                                           "ACTIVE" if finding.startswith("REPORT_ACTIVE") or finding == "REPORT_RESTORE_RISK" else "PRESENT", obs.evidence_id))
                state = {"DISABLE_DATA_FLOW": "DISABLED", "BLOCK_RESTORE": "BLOCKED", "DELETE_RECORD": "ABSENT",
                         "REDACT_RECORD": "REDACTED", "ANONYMIZE_RECORD": "ANONYMIZED"}[action]
                remedies.append(self._step("REMEDIATION", obs.system_id, obs.resource_id, action, state, ""))
                op, state = self._verify(action)
                verification.append(self._step("VERIFICATION", obs.system_id, obs.resource_id, op, state, ""))
            else:
                # A readback can prove an absent record, a disabled flow, a blocked restore,
                # or a compliant retained/anonymized record.
                if not obs.present:
                    compliant.append(self._step("VERIFICATION", obs.system_id, obs.resource_id, "VERIFY_RECORD_ABSENT", "ABSENT", obs.evidence_id))
                elif obs.system_id == "integration_service" and obs.active is False:
                    compliant.append(self._step("VERIFICATION", obs.system_id, obs.resource_id, "VERIFY_DATA_FLOW_DISABLED", "DISABLED", obs.evidence_id))
                elif obs.system_id == "backup_service" and obs.restore_allowed is False:
                    compliant.append(self._step("VERIFICATION", obs.system_id, obs.resource_id, "VERIFY_RESTORE_BLOCKED", "BLOCKED", obs.evidence_id))
                elif action == "ANONYMIZE_RECORD" and not obs.pii:
                    compliant.append(self._step("VERIFICATION", obs.system_id, obs.resource_id, "VERIFY_RECORD_ANONYMIZED", "ANONYMIZED", obs.evidence_id))
        if findings:
            findings.sort(key=lambda x: (FIND_ORDER[x["operation"]], x["system_id"], x["resource_id"]))
            remedies.sort(key=lambda x: (FIX_ORDER[x["operation"]], x["system_id"], x["resource_id"]))
            verification.sort(key=lambda x: (VERIFY_ORDER[x["operation"]], x["system_id"], x["resource_id"]))
            steps = findings + remedies + verification
            status = "INCOMPLETE"
        else:
            compliant.sort(key=lambda x: (VERIFY_ORDER[x["operation"]], x["system_id"], x["resource_id"]))
            steps, status = compliant, "COMPLETE"
        for no, step in enumerate(steps, 1):
            step["step_no"] = no
        return status, steps

    def run(self, requests_file: Path, output: Path) -> None:
        with requests_file.open(encoding="utf-8", newline="") as handle:
            requests = sorted(csv.DictReader(handle), key=lambda r: r["case_id"])
        with output.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=["case_id", "deletion_status", "steps_json"])
            writer.writeheader()
            for request in requests:
                status, steps = self.audit(request)
                writer.writerow({"case_id": request["case_id"], "deletion_status": status,
                                 "steps_json": json.dumps(steps, separators=(",", ":"), ensure_ascii=False)})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=ROOT / "dataset")
    parser.add_argument("--requests", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "output.csv")
    args = parser.parse_args()
    AuditEngine(args.dataset).run(args.requests or args.dataset / "deletion_requests.csv", args.output)


if __name__ == "__main__":
    main()
