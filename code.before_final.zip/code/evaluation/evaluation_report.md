# Evaluation report

## Executed public-sample evaluation

Run on 2026-10-24 with `python code/main.py --requests dataset/sample_deletion_requests.csv --output sample_predictions.csv`.

| Metric | Result |
| --- | ---: |
| Cases | 32 |
| Status accuracy | 21 / 32 (65.6%) |
| Exact row / sequence accuracy | 0 / 32 (0.0%) |
| JSON-array validity | 32 / 32 (100%) |

The exact-row score compares deletion status and the parsed `steps_json` array. It is deliberately reported as zero rather than presenting schema validity as correctness.

## Additional deterministic tests

`python code/test_main.py -v` passed 3/3 tests:

1. A historical request email resolves to the same stable subject.
2. An export-only request is not treated as deletion authorization.
3. A permanent deletion request is authorized.

## Failures found and improvements made

The first run revealed a Windows SQLite temporary-file error; SQL snapshots now execute in an in-memory database. It also revealed that repeated SQL parsing would be expensive, so the engine now requires a matched resolved identifier before parsing an artifact. Remaining sample misses are primarily artifacts in PNG/PDF evidence, richer policy context (retained security records and tombstones), and verification planning for records not directly observed. The current output is schema-valid but needs those extensions before it should be treated as a high-accuracy submission.
